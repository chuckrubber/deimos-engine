import pygame as pg

def intialize():
    pg.init()

def demo():
    window = pg.display.set_mode((500, 500))
    while True:
        pass

def main():
    print("success")