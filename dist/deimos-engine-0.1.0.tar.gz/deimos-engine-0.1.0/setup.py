# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['deimos_engine']

package_data = \
{'': ['*']}

install_requires = \
['pygame>=2.1.2,<3.0.0']

entry_points = \
{'console_scripts': ['deimos-engine = deimos_engine.core:main']}

setup_kwargs = {
    'name': 'deimos-engine',
    'version': '0.1.0',
    'description': 'A simple engine for demos',
    'long_description': '## DEIMOS ENGINE',
    'author': 'John',
    'author_email': 'jmancoding@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/chuckrubber/deimos-engine',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
